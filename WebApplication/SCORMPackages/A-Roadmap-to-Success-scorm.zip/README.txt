This is a stand-alone version of the A Roadmap to Success: Hiring, Retaining and Including People with Disabilities course.

It was converted from the version that exists on hru.gov as of July 2018.

It does not require an LMS to run.  This means it stores no user data.  A user must complete the course
within one sitting.  At the end of the course, a blue bar appears at the top of the screen with a
Certificate button which allows the user to enter their name and print a completion certificate.

To start the course, run the index.htm file in a browser.